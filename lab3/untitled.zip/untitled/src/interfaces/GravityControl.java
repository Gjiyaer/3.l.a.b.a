package interfaces;

public interface GravityControl {
    void controlInGravity();
}
