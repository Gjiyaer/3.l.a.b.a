package interfaces;

public interface ZeroGravityControl {
    void controlInZeroGravity();
}
