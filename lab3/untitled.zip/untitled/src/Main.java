import enume.Places;
import enume.TypesOfDrawings;
import object.*;

import java.util.Arrays;

import static enume.TypesOfDrawings.*;

public class Main {
    public static void main(String[] args) {
        Rocket rocket = new Rocket("Описание управления в условиях тяжести");
        LastStage lastStage = new LastStage("Описание управления в условиях тяжести", "Описание управления в невесомости");
        Znaika znaika = new Znaika();
        Pribor pribor = new Pribor(Arrays.asList("Функция 1", "Функция 2", "Функция 3"));
        Fucsia fucsia = new Fucsia("Фуксия", Places.CITY, "Описание");
        Seledochka seledochka = new Seledochka("Селедочка", Places.CITY, "Описание");
        EngineersCharacter engineersCharacter = new EngineersCharacter("Инженер", Places.CITY, "Описание");

        znaika.определитьПозициюИПроверитьНаличиеЛунита();

        System.out.println("Описание управления в условиях тяжести: " + rocket.getОписаниеУправленияВУсловияхТяжести());
        System.out.println("Описание управления в невесомости: " + lastStage.getОписаниеУправленияВНевесомости());
        System.out.println("Количество управлений: " + lastStage.количествоУправлений());
        System.out.println("Описание прибора: " + pribor.достатьОписания());

        fucsia.начатьРаботуОдним();
        fucsia.принестиРезультатВГородок();

        seledochka.начатьРаботу();
        seledochka.принестиРезультатВГородок();

        engineersCharacter.toString(TypesOfDrawings.MECHANICAL);
        engineersCharacter.toString(TypesOfDrawings.ELECTRIC);
        engineersCharacter.toString(TypesOfDrawings.ARCHITECTURAL);
    }
}