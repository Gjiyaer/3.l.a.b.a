package enume;

public enum Places {
    MOON("Луну"),
    CAVE("пещер"),
    CITY("Научный городок"),
    FACILITY("различные заводы");

    private final String descr;
    Places (String des){
        this.descr = des;
    }
    @Override
    public String toString(){
        return descr;
    }
}