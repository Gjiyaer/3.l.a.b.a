package enume;

public enum Objects {
    LUNIT("лунита");
    private final String descr;

    Objects (String des){
        this.descr = des;
    }
    @Override
    public String toString(){
        return descr;
    }
}
