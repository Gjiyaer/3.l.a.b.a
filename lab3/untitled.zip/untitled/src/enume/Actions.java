package enume;

public enum Actions {
    OTLIVOC("отливок "),
    SHTAMPOVCA("штамповок"),
    PACOVKA("поковок "),
    ENAVER("также для изготовления разнообразной аппаратуры"),
    UNDERSTAND("поймет ли ");


    private final String descr;

    Actions(String des){
        this.descr  = des;
    }

    @Override
    public String toString(){
        return descr;
    }
}