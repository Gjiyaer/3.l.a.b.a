package enume;

public enum TypesOfDrawings {
    //виды чертежей
        MECHANICAL("Механический"),
        ELECTRIC("Электрический"),
        ARCHITECTURAL("Архитектурный");

    private final String descr;

    TypesOfDrawings(String des){
        this.descr  = des;
    }

    @Override
    public String toString(){
        return descr;
    }
}
