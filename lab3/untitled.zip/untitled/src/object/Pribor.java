package object;
import java.util.List;

    public class Pribor {
        private List<String> function;

        public Pribor(List<String> function) {
            this.function = function;
        }

        public List<String> getDescription() {
            return function;
        }

        public String достатьОписания() {

            return null;
        }
    }

