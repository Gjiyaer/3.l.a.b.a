package object;

import enume.Actions;
import enume.Objects;
import enume.Places;

public class Rocket  {
    private String name;
    private int numberOfControls;

    public Rocket(String name) {
        this.name = name;
        this.numberOfControls = 0;
    }

    public void fly() {
        System.out.println("Управление ракетой в невесомости");
        numberOfControls++;
    }

    public int getNumberOfControls() {
        return numberOfControls;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getОписаниеУправленияВУсловияхТяжести() {
        return 2;
    }
}