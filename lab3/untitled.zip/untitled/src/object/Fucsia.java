package object;

import enume.Places;

public class Fucsia extends EngineersCharacter{
    public Fucsia(String name, Places city, String string) {
        super(name,city,string);
    }

    public void начатьРаботуОдним() {
        // Логика работы Фуксии одним инженером
        System.out.println("Фуксия начинает работу одним инженером");
    }

    public void принестиРезультатВГородок() {
        // Логика принесения результатов работы в городок
        System.out.println("Фуксия принесла результаты работы в городок");
    }

    public void начатьРаботуСДругимиИнженерами() {
        // Логика начала работы с другими инженерами
        System.out.println("Фуксия начинает работу с другими инженерами");
    }

    public void начатьРаботу() {
    }
}