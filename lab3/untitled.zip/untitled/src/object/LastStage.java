package object;

import interfaces.GravityControl;

public class LastStage extends Rocket implements GravityControl {
    private final String descriptionZeroGravityControl;
    private String name;

    public LastStage(String descriptionZeroGravityControl, String descriptionGravityControl) {
        super(descriptionGravityControl);
        this.descriptionZeroGravityControl = descriptionZeroGravityControl;
    }

    public int TwoControls() {
        return 2;
    }

    public String getОписаниеУправленияВНевесомости() {
    return null;
    }

    public int количествоУправлений() {
        return 2;
    }

    @Override
    public void controlInGravity() {

    }
}


