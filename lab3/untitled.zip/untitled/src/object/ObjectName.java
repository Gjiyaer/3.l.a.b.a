package object;

import enume.TypesOfDrawings;
import interfaces.GravityControl;

public abstract class ObjectName implements GravityControl {
    String name;

    public ObjectName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public abstract void toString(TypesOfDrawings typesOfDrawings);
}
