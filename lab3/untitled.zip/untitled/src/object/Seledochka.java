package object;

import enume.Places;

public class Seledochka extends EngineersCharacter{
    public Seledochka(String name, Places place, String a) {
        super(name, place, a);
    }

    public void начатьРаботуОдним() {
        // Логика работы Селедочки одним инженером
        System.out.println("Селедочка начинает работу одним инженером");
    }

    public void принестиРезультатВГородок() {
        // Логика принесения результатов работы в городок
        System.out.println("Селедочка принесла результаты работы в городок");
    }

    public void начатьРаботу() {
    }
}