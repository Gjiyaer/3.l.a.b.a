package object;

import enume.Actions;
import enume.Objects;
import enume.Places;
import enume.TypesOfDrawings;


public class EngineersCharacter extends ObjectName {
    private final String a;
    private Places place;

    public EngineersCharacter(String name, Places place, String a) {
        super(name);
        this.place = place;
        this.a = a;
    }

    public void retObject(Objects obj) {
        System.out.print(obj.toString());
    }

    public void doAction(Actions act) {
        System.out.print(act.toString());
    }

    public Places getPlace() {
        return place;
    }

    public void doAction(String act, EngineersCharacter a) {
        System.out.print(act);
        final String name1 = getName();
        System.out.print(a.getName());
    }

    @Override
    public void controlInGravity() {
        // Логика управления в условиях тяжести
    }

    @Override
    public void toString(TypesOfDrawings typesOfDrawings) {
        // Логика преобразования в строку с учетом типа чертежа
    }
}